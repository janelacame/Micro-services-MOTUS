const { setDefaultResultOrder } = require('dns');
const port = process.env.PORT || 3000 // port par défaut mais possible de créer un autre serveur depuis le term linux : "PORT=4000 node api.js"
const express = require('express');
const app = express();
const os = require('os');
const storage = require('node-sessionstorage')
const session = require('express-session')
const jwt = require('jsonwebtoken')

var fs = require('fs');
const { randomBytes } = require('crypto');
var array = fs.readFileSync('liste_francais_utf8.txt').toString().split('\n');
console.log(array)

date = new Date().getDate()
date2 = 32
function checkDate(date1,date2){
    if(date1 != date2){
        d = Math.random()*array.length*3
        index =  d % array.length
        mot = array[Math.floor(index)]
        console.log(mot)
        return(mot)
    }
}

app.use(express.static("www"))
app.use(session({secret:'keyboard cat',
                saveUninitialized:true,
                cookie:{maxAge : 1000*60*60*24},
                resave: false
                }
                ))

app.get('/word', (req, res) => {
    checkDate(date,date2)
    res.end(mot)
})

app.get('/os', (req, res) => {
    res.send(os.hostname() + "port " + port)
})

app.get('/port', (req, res) => {
    res.send(`MOTUS APP listening on port `+port);
})

app.get('/callback',function(req,res){
    var token = req.query.code 
    console.log(token)
    var user = ''
    jwt.verify(token, 'shhhhh', function(err, decoded){
        console.log('decoded foo',decoded.foo) 
        user = decoded.foo
    });
    res.redirect('http://localhost:3000/')
    storage.setItem('user',user)
    console.log(storage.getItem('user'))
})

app.get('/callback_score',function(req,res){
    var token = req.query.code
    var score = ''
    jwt.verify(token, 'shhhhh', function(err, decoded) {
        score = decoded.foo
        storage.setItem('score',JSON.stringify(score))
      });
    res.redirect('http://localhost:3000/score.html')
})

app.get('/score',function(req,res){
    res.send(storage.getItem('score'))
})

app.get('/user',function(req,res){
    res.send(storage.getItem('user'))
    return storage.getItem('user')
})

app.get('/phoneCode', (req,res) => {
    res.send("312606")
})

app.listen(port, () => {
    console.log('App listening on port' + port + '/');
})

