const { setDefaultResultOrder } = require('dns');
const port = process.env.PORT || 5000 
const express = require('express');
const app = express();
const session = require('express-session')
const fs = require('fs');
const jwt = require('jsonwebtoken')

app.use(express.static("www3"))
app.use(session({secret:'keyboard cat',
                saveUninitialized:true,
                cookie:{maxAge : 1000*60*60*24},
                resave: false
                }
                ))


app.get("/", function(req,res){
    req.session.name = "Session MOTUS"
    return res.send("Session Set")
})

app.get("/session", function(req,res){
    var name = req.session.name
    return res.send(name)
})

app.get("/authorize",function(req,res){
    //console.log(req.query.client_id)
    //console.log(req.query.scope)
    //console.log(req.query.redirected_uri)
    //console.log(req.query.nounce)
    res.redirect('http://localhost:5000/login.html')
})

app.get('/checkid/:id/:psw',function(req,res){
    var data = fs.readFile('./bdd_authen.json','utf8',function(err,data){
        if (err) throw err;
        data = JSON.parse(data)
        const keys = Object.keys(data);
        if(keys.includes(req.params.id)){
            if(data[req.params.id]['psw'] == req.params.psw){
                var token = jwt.sign({ foo: req.params.id }, 'shhhhh');
                res.send('<script>window.location.href="http://localhost:3000/callback?code='+token+'" ;</script>');
            }else{
                res.send('<script> alert("tu t\'es trompé bouffon! UwU xD");window.location.href="/login.html" ;</script>');
            }
        }else{
            res.redirect('http://localhost:5000/setPsw/'+req.params.id+'/'+req.params.psw)
        }
})})

app.get('/setPsw/:user/:psw', (req, res) => {
    var data = fs.readFile('./bdd_authen.json','utf8',function(err,data){
        if (err) throw err;
        data = JSON.parse(data)
        data[req.params.user] = {"psw" :req.params.psw}
        new_value = JSON.stringify(data)
        fs.writeFile('./bdd_authen.json',new_value,'utf8', function(err){
            if (err) throw err;
            console.log('filelist async complete')
        })
    })
    res.redirect('http://localhost:5000/checkid/'+req.params.user+'/'+req.params.psw)
})

app.get('/login', (req,res) => {
    if(req.session.token){
    res.redirect('http://localhost:5000/login.html')}
    else{
        res.send('Tu t\'es trompé UwU')
    }
})

app.listen(port, () => {
    console.log('App score listening on port' + port + '/');
 })

