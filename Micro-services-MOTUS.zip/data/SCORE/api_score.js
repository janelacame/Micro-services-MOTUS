const port = process.env.PORT || 4000 
const express = require('express');
const app = express();
const fs = require('fs');
const jwt = require('jsonwebtoken')

app.use(express.static("www2"))

app.get('/getScore', (req, res) => {
    var user = req.query.user
    var token = ''
    res.header('Access-Control-Allow-Origin', '*') 
    fs.readFile('./bdd_score.json', 'utf8', (err, data) => {
        if (err) {
            console.log(`Error reading file from disk: ${err}`);
        } else {
            data = JSON.parse(data)
            const keys = Object.keys(data);
            if(keys.includes(user)){
                token = jwt.sign({ foo:  data[user]['score']}, 'shhhhh');
                res.send('<script>window.location.href="http://localhost:3000/callback_score?code='+token+'" ;</script>');
            }else{
                token  = jwt.sign({ foo:  '1'}, 'shhhhh');
                res.send('<script>window.location.href="http://localhost:3000/callback_score?code='+token+'" ;</script>');
            }    
        }
    }); 
})

app.get('/setScore/:user/:score', (req, res) => {
    var data = fs.readFile('./bdd_score.json','utf8',function(err,data){
        if (err) throw err;
        data = JSON.parse(data)
        const keys = Object.keys(data);
        if(keys.includes(req.params.user)){
            data[req.params.user]['score'].push(JSON.parse(req.params.score))
        }else{
            data[req.params.user] = {'score' :[JSON.parse(req.params.score)]}
        }
        new_value = JSON.stringify(data)

        fs.writeFile('./bdd_score.json',new_value,'utf8', function(err){
            if (err) throw err;
            console.log('filelist async complete')
        })
    })
    res.redirect('http://localhost:4000/getScore?user='+req.params.user)
})

app.listen(port, () => {
    console.log('App score listening on port' + port + '/');
 })

